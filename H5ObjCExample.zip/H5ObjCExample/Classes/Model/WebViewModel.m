//
//  CallEachModel.m
//  H5ObjCExample
//
//  Created by lc-macbook pro on 2017/7/8.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "WebViewModel.h"
#import "BaseViewController.h"

@implementation WebViewModel


#pragma mark - jsCallOC

- (void)jsCallOC {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil
                                                        message:@"jsCallOC"
                                                       delegate:nil
                                              cancelButtonTitle:@"I konw"
                                              otherButtonTitles:nil, nil];
        [alert show];
    });
}


- (void)jsCallOCWithString:(NSString *)string {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:string
                                                        message:nil
                                                       delegate:nil
                                              cancelButtonTitle:@"I konw"
                                              otherButtonTitles:nil, nil];
        [alert show];
    });
}
- (void)jsCallOCWithTitle:(NSString *)title message:(NSString *)msg {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                        message:msg
                                                       delegate:nil
                                              cancelButtonTitle:@"I konw"
                                              otherButtonTitles:nil, nil];
        [alert show];
    });
}



- (void)jsCallOCWithDictionary:(NSDictionary *)dictionary {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:dictionary[@"title"]
                                                        message:dictionary[@"message"]
                                                       delegate:nil
                                              cancelButtonTitle:@"I konw"
                                              otherButtonTitles:nil, nil];
        [alert show];
    });
    
    NSLog(@"===== %@",dictionary);
}

- (void)jsCallOCWithArray:(NSArray *)array {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:array[0]
                                                        message:array[1]
                                                       delegate:nil
                                              cancelButtonTitle:@"I konw"
                                              otherButtonTitles:nil, nil];
        [alert show];
    });
    
    NSLog(@"===== %@",array);
}




#pragma mark - OCCallJS
- (void)ocCallJS {
    JSValue *jsFunc = self.jsContext[@"func1"];
    [jsFunc callWithArguments:nil];
}


- (void)ocCallJSWithString:(NSString *)string {
    NSInteger arc = arc4random()%1000;
    JSValue *jsFunc = self.jsContext[@"func2"];
    [jsFunc callWithArguments:@[@{@"title": @"change--> myoctitle", @"message": @(arc)}]];
}



- (void)ocCallJSWithTitle:(NSString *)title message:(NSString *)message {

}

- (void)ocCallJSWithDictionary:(NSDictionary *)dictionary {

}
- (void)ocCallJSWithArray:(NSArray *)array {
   
}


#pragma mark - callEach
- (void)jsCallOCAndOCCallJSWithParams:(NSDictionary *)params {
    [self.currentVC createTopView];
    self.currentVC.field.text = params[@"title"];
    
    [self.currentVC setBlock:^(NSString *string){
        if (string != nil && string.length > 0) {
            JSValue *jsFunc = self.jsContext[@"func2"];
            [jsFunc callWithArguments:@[@{@"title":@"js 调出来topView 输入填充到html：" , @"message": string}]];
        }
    }];
}


- (void)ocCallJSAndJSCallOCWithParams:(NSDictionary *)params {
    JSValue *jsFunc = self.jsContext[@"func3"];
    [jsFunc callWithArguments:@[@{@"title": @"myoctitle", @"message": @"myocmessage"}]];
}

@end


