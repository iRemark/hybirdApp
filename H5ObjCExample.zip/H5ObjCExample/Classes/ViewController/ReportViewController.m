//
//  ReportViewController.m
//  H5ObjCExample
//
//  Created by lc-macbook pro on 2017/7/8.
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "ReportViewController.h"

@interface ReportViewController () <UIWebViewDelegate>
@property (nonatomic, strong) UIWebView *webView;
@property (nonatomic, strong) UIView *myView;
@end

@implementation ReportViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.webView];
    [self.view addSubview:self.myView];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"混合" style:UIBarButtonItemStyleDone target:self action:@selector(showdiy:)];
    self.navigationItem.rightBarButtonItem = item;
}

- (void)showdiy:(UIBarButtonItem *)item {
    self.myView.hidden = !self.myView.hidden;
}

- (UIWebView *)webView {
    if (_webView == nil) {
        _webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth-10, kScreenHeight)];
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"report" withExtension:@"html"];
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        [_webView loadRequest:request];
        
        _webView.scalesPageToFit = NO;
        _webView.delegate = self;
    }
    
    return _webView;
}

- (UIView *)myView {
    if (_myView==nil) {
        _myView = [[UIView alloc]initWithFrame:CGRectMake(0, 64, kScreenWidth, 58)];
        _myView.backgroundColor = [UIColor whiteColor];
        
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 10, 100, 40)];
        label.textAlignment = NSTextAlignmentRight;
        label.text = @"查询结果：";
        [_myView addSubview:label];
        
        UITextField *field = [[UITextField alloc]initWithFrame:CGRectMake(100, 10, 200, 40)];
        field.borderStyle = UITextBorderStyleRoundedRect;
        field.placeholder = @"请输入条件";
        [_myView addSubview:field];
        
        
        UILabel *label2 = [[UILabel alloc]initWithFrame:CGRectMake(300, 10, 100, 40)];
        label2.textAlignment = NSTextAlignmentRight;
        label2.text = @"日期：";
        [_myView addSubview:label2];
        
        UITextField *field2 = [[UITextField alloc]initWithFrame:CGRectMake(400, 10, 200, 40)];
        field2.borderStyle = UITextBorderStyleRoundedRect;
        field2.placeholder = @"请选择日期";
        [_myView addSubview:field2];
        
        _myView.hidden = YES;
    }
    return _myView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
