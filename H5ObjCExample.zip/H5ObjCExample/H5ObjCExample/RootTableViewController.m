//
//  RootTableViewController.m
//  H5ObjCExample
//
//  Created by lc-macbook pro on 2017/7/8.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "RootTableViewController.h"



#define kTitle      @"cell_title"
#define kSubTitle   @"cell_subtitle"


static NSString *cellID = @"RootTableViewControllerCellID";

@interface RootTableViewController ()

@property (nonatomic, strong) NSMutableArray *dataList;

@end

@implementation RootTableViewController

#pragma mark - lazy load
- (NSMutableArray *)dataList {
    if (_dataList == nil) {
        _dataList = [NSMutableArray array];
    }
    return _dataList;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
     self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    
    [self.dataList addObject:@{kTitle:@"H5和OC相互调用--UIWebView",kSubTitle:@"WebViewController"}];
    [self.dataList addObject:@{kTitle:@"H5和OC相互调用--WKWebView",kSubTitle:@"WKWebViewController"}];
    [self.dataList addObject:@{kTitle:@"H5和OC相互调用--UIWebView_JSBridge",kSubTitle:@"JSBridgeViewController"}];
    [self.dataList addObject:@{kTitle:@"三方组件--hybird",kSubTitle:@""}];
    [self.dataList addObject:@{kTitle:@"我们项目--iShop报表样式",kSubTitle:@"ReportViewController"}];
    [self.dataList addObject:@{kTitle:@"我们项目--iShop单据样式",kSubTitle:@"BillViewController"}];
    
    
    self.title = @"H5Objc";
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    }
    if (self.dataList.count > indexPath.row) {
        NSDictionary *dataDictionary = self.dataList[indexPath.row];
        cell.textLabel.text = dataDictionary[kTitle];
        cell.detailTextLabel.text = dataDictionary[kSubTitle];
        cell.detailTextLabel.textColor = [UIColor lightGrayColor];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    if (self.dataList.count > indexPath.row) {
        NSDictionary *dataDictionary = self.dataList[indexPath.row];
        Class cls = NSClassFromString(dataDictionary[kSubTitle]);
        if (cls) {
            UIViewController *vc = [[cls alloc]init];
            if (vc) {
                vc.title = dataDictionary[kTitle];
                [self.navigationController pushViewController:vc animated:YES];
            }
        }
    }
}

@end


