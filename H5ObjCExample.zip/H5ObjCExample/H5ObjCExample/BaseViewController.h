//
//  BaseViewController.h
//  H5ObjCExample
//
//  Copyright © 2017年 http://www.cnblogs.com/saytome/. All rights reserved.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

@property (copy, nonatomic) void(^block)(id result);

@property (nonatomic, strong) UITextField *field;

- (void)createTopView;

@end
